import React from "react";
import "./BreakTime.css";

const BreakTime = ({ breakTime, isActive, onBreakClick }) => {
  return (
    <button
      className={`break-btn ${isActive ? "active" : ""}`} // Apply 'active' class conditionally
      onClick={() => onBreakClick(breakTime)}
    >
      {breakTime}s
    </button>
  );
};
export default BreakTime;
